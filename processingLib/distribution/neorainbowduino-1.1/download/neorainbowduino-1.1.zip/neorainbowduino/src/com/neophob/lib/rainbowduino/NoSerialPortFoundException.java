package com.neophob.lib.rainbowduino;

public class NoSerialPortFoundException extends Exception {

}
